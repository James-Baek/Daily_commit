package com.ssafy.mdoel.dao;

import java.util.List;

import com.ssafy.model.dto.Product;

public interface ProductDao {
	public Product select(String id);
	public List<Product> selectAll();
	public void insert(Product product);
	public void update(Product product);
	public void delete(String id);
}
