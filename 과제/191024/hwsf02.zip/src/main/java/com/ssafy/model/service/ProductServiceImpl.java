package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.mdoel.dao.ProductDao;
import com.ssafy.model.dto.Product;
import com.ssafy.model.dto.ProductException;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductDao dao;
	
	public Product select(String id) {
		try {
			return dao.select(id);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("상품 목록 조회 중 오류 발생");
		}
	}

	public List<Product> selectAll() {
		try {
			return dao.selectAll();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("");
		}
	}

	public void insert(Product product) {
		try {
			dao.insert(product);
		} catch (Exception e) {
			throw new ProductException("상품 입력 중 오류 발생");
		}
	}

	public void update(Product product) {
		try {
			dao.update(product);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("상품 수정 중 오류 발생");
		}
	}

	public void delete(String id) {
		try {
			dao.delete(id);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ProductException("상품 삭제 처리 중 오류 발생");
		}
	}

}
